# Karrot Shrine v1

Contains contracts, frontend, and deployment info.