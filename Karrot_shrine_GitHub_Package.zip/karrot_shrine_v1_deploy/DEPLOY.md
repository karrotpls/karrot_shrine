# Deployment Instructions

1. Compile in Remix
2. Deploy to PulseChain
3. Verify contracts
